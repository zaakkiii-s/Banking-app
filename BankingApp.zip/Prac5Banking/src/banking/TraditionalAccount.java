package banking;

public class TraditionalAccount extends BankAccount implements InterestBearingAccount {
	private static final double INTEREST_RATE = 0.015;
	private static final double MONTHLY_FEE = 50;
	
	public TraditionalAccount(int accountNumber, String accountHolder, double openingBalance) {
		super(accountNumber, accountHolder, openingBalance);
		
	}
	@Override
	public void deductFees() {
		balance -= MONTHLY_FEE;
		transactionCount = 0;
	}
	public boolean withdraw(double amount) {
		if(balance-amount>+ 500) {
			balance -= amount;
			return true;
		}else { 
			System.out.println("Insufficient funds");;
			return false;
		}
	}
	public void addInterest() {
		if(getBalance()> 500) {
			deposit(INTEREST_RATE * getBalance());
		}
	}
}
