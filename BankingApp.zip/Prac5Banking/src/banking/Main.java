public class BankingApplication {
    public static void main(String[] args) {
        ArrayList<BankAccount> accounts = new ArrayList<>();

        try {
            Scanner accountsScanner = new Scanner(new File("accounts.txt"));
            while (accountsScanner.hasNextLine()) {
                String[] accountInfo = accountsScanner.nextLine().split("\t");
                int accountNumber = Integer.parseInt(accountInfo[0]);
                String accountHolder = accountInfo[1];
                double balance = Double.parseDouble(accountInfo[2]);

                if (accountNumber % 2 == 0) {
                    accounts.add(new TraditionalAccount(accountNumber, accountHolder, balance));
                } else {
                    accounts.add(new ShariahAccount(accountNumber, accountHolder, balance));
                }
            }
            accountsScanner.close();

            Scanner transactionsScanner = new Scanner(new File("transact.txt"));
            while (transactionsScanner.hasNextLine()) {
                String[] transactionInfo = transactionsScanner.nextLine().split("\t");
                int sourceAccountNumber = Integer.parseInt(transactionInfo[0]);
                int targetAccountNumber = Integer.parseInt(transactionInfo[1]);
                double amount = Double.parseDouble(transactionInfo[2]);

                BankAccount sourceAccount = null;
                BankAccount targetAccount = null;
                for (BankAccount account : accounts) {
                    if (account.getAccountNumber() == sourceAccountNumber) {
                        sourceAccount = account;
                    }
                    if (account.getAccountNumber() == targetAccountNumber) {
                        targetAccount = account;
                    }
                }

                if (sourceAccount != null && targetAccount != null) {
                    sourceAccount.transferTo(targetAccount, amount);
                }
            }
            transactionsScanner.close();

            for (BankAccount account : accounts) {
                if (account instanceof TraditionalAccount) {
                    TraditionalAccount traditionalAccount = (TraditionalAccount) account;
                    traditionalAccount.deductFees();
                    traditionalAccount.addInterest();
                } else if (account instanceof ShariahAccount) {
                    ShariahAccount shariahAccount = (ShariahAccount) account;
                    shariahAccount.deductFees();
                }

                account.printStatement();
            }
        } catch (FileNotFoundException e) {
            System.out.println("File not found.");
        }
    }
}
