package banking;

public class ShariahAccount extends BankAccount{
	private static final double TRANSACTION_FEE = 1.80;
	private static final int FREE_TRANSACTIONS = 5;
	
	public ShariahAccount(int accountNumber, String accountHolder, double openingBalance) {
		super(accountNumber, accountHolder, openingBalance);
	}
	@Override
	public void deductFees() {
		if(getTransactionCount()> 5) {
			balance -= (getTransactionCount()- FREE_TRANSACTIONS) * TRANSACTION_FEE;
			
		}
		transactionCount = 0;
	}
	public boolean withdraw(double amount) {
		if(getBalance()- amount >=0) {
			balance -= amount;
			return true;
			
		}else {
			System.out.println("insuffiecient funds");
			return false;
		}
	}
}
